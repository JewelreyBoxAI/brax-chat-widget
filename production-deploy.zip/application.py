#!/usr/bin/env python3
"""
Production-grade Azure App Service entry point for Brax Fine Jewelers AI Assistant
"""
import sys
import os

# Add src to Python path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

try:
    from app import app
    
    # Health check endpoint for Azure
    @app.get("/robots933456.txt")
    async def azure_health():
        return {"status": "healthy", "service": "brax-jewelers-ai"}
        
except Exception as e:
    # Fallback error handling
    import logging
    logging.error(f"Failed to import app: {e}")
    raise

# Export for gunicorn
application = app

if __name__ == "__main__":
    import uvicorn
    port = int(os.environ.get("PORT", 8000))
    uvicorn.run(app, host="0.0.0.0", port=port, log_level="info")